
export default class Deck {
    constructor (config) {
    }

    shuffle () {
    }

    draw () {
    }

    getCardsCount () {
    }
}