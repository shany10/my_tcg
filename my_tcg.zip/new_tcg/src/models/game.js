
export default class Game {
    constructor (config) {
        this.up = config.up;
        this.down = config.down;
    }
}